-- phpMyAdmin SQL Dump
-- version 4.4.11
-- http://www.phpmyadmin.net
--
-- Host: localhost:8080
-- Generation Time: Aug 27, 2015 at 11:46 PM
-- Server version: 5.6.26
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--
CREATE DATABASE IF NOT EXISTS `library` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `library`;

-- --------------------------------------------------------

--
-- Table structure for table `authors`
--

CREATE TABLE IF NOT EXISTS `authors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authors`
--

INSERT INTO `authors` (`id`, `name`) VALUES
(1, 'the thrill'),
(2, 'the thrill'),
(3, 'the thrill'),
(4, 'this guy'),
(5, 'this guy'),
(6, 'yoyoy'),
(7, 'yoyoy'),
(8, 'yoyoy'),
(9, 'yo'),
(10, 'yo'),
(11, 'yo'),
(12, 'yo'),
(13, 'hey'),
(14, 'hey'),
(15, 'hey'),
(16, 'man'),
(17, 'man'),
(18, 'man'),
(19, 'man'),
(20, 'man'),
(21, 'man'),
(22, 'man'),
(23, 'man'),
(24, 'man'),
(25, 'man'),
(26, 'hey'),
(27, 'hey'),
(28, 'man'),
(29, 'man'),
(30, 'guy'),
(31, 'alex'),
(32, 'peterson'),
(33, 'bsfas'),
(34, 'jinks'),
(35, 'jinks'),
(36, 'guy'),
(37, 'route'),
(38, 'enemy'),
(39, 'someone'),
(40, 'sdsada'),
(41, 'that chick'),
(42, 'that chick'),
(43, 'that chick'),
(44, 'that chick'),
(45, 'that chicl'),
(46, 'Jonathan Safran Foer'),
(47, 'Jonathan Ferris'),
(48, 'Jonathan Safran Foer'),
(49, 'Jonathan Ferris'),
(50, 'Anthony Burgess'),
(51, 'Jonathan Safran Foer'),
(52, 'Jonathan Safran Foer'),
(53, 'Timothy Ferris'),
(54, 'Alex, Deron, Phil'),
(55, 'Alex, Deron, Phil'),
(56, 'Alex, Deron, Phil'),
(57, 'Jonathan Safran Foer'),
(58, 'Jonathan Safran Foer, Jim'),
(59, 'Jonathan Safran Foer, Jim'),
(60, 'Hey,hey'),
(61, 'Hey,hey'),
(62, 'first author, second author'),
(63, 'first author, second author'),
(64, 'this, is, a, test'),
(65, 'hey, man, author'),
(66, 'hey, man, author'),
(67, 'hey, man, author'),
(68, 'first, second, third'),
(69, 'first, second, third'),
(70, 'first, second, third'),
(71, 'first'),
(72, 'second'),
(73, 'third'),
(74, 'jim'),
(75, 'john'),
(76, 'joe'),
(77, 'dan brown'),
(78, ' this guy'),
(79, 'dan brown'),
(80, 'John Smith'),
(81, 'John Guy'),
(82, 'John Smith'),
(83, 'John Guy'),
(84, 'Alex,'),
(85, 'Deron,'),
(86, 'Phil'),
(87, 'Alex,'),
(88, 'Deron,'),
(89, 'Phil'),
(90, 'Alex'),
(91, 'Brown');

-- --------------------------------------------------------

--
-- Table structure for table `authorships`
--

CREATE TABLE IF NOT EXISTS `authorships` (
  `id` int(11) NOT NULL,
  `book_id` bigint(20) DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `authorships`
--

INSERT INTO `authorships` (`id`, `book_id`, `author_id`) VALUES
(17, 48, 48),
(18, 49, 49),
(19, 50, 50),
(20, 51, 51),
(21, 52, 52),
(22, 53, 53),
(56, 73, 87),
(57, 73, 88),
(58, 73, 89),
(59, 74, 90),
(60, 74, 91);

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`) VALUES
(48, 'Extremely Loud and Incredibly Close'),
(49, 'To Rise Again at a Decent Hour'),
(50, 'A Clockwork Orange'),
(51, 'Everything is Illuminated'),
(52, 'Tree of Codes'),
(53, '4 Hour Chef'),
(73, 'What did ya do?'),
(74, 'A Memoir');

-- --------------------------------------------------------

--
-- Table structure for table `checkouts`
--

CREATE TABLE IF NOT EXISTS `checkouts` (
  `id` int(11) NOT NULL,
  `patron_id` bigint(20) DEFAULT NULL,
  `copy_id` bigint(20) DEFAULT NULL,
  `due_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `copies`
--

CREATE TABLE IF NOT EXISTS `copies` (
  `id` int(11) NOT NULL,
  `book_id` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `copies`
--

INSERT INTO `copies` (`id`, `book_id`) VALUES
(48, 48),
(49, 49),
(50, 50),
(51, 51),
(52, 52),
(53, 53),
(73, 73),
(74, 74);

-- --------------------------------------------------------

--
-- Table structure for table `patrons`
--

CREATE TABLE IF NOT EXISTS `patrons` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(10) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authors`
--
ALTER TABLE `authors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `authorships`
--
ALTER TABLE `authorships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `checkouts`
--
ALTER TABLE `checkouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `copies`
--
ALTER TABLE `copies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patrons`
--
ALTER TABLE `patrons`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `authors`
--
ALTER TABLE `authors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=92;
--
-- AUTO_INCREMENT for table `authorships`
--
ALTER TABLE `authorships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT for table `checkouts`
--
ALTER TABLE `checkouts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `copies`
--
ALTER TABLE `copies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT for table `patrons`
--
ALTER TABLE `patrons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
